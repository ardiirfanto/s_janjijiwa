<?php $__env->startSection('title', 'Hasil Klasifikasi'); ?>
<?php $__env->startSection('breadcumb'); ?>
    <li class="breadcrumb-item"><a href="javascript:void(0);">Pengujian</a></li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('uji.proses')); ?>">Proses Klasifikasi

        </a>
    </li>
    <li class="breadcrumb-item active">Hasil Klasifikasi</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h4 class="mt-0 header-title">Grafik Hasil Pengujian | <?php echo e($testing->nama_testing); ?></h4>
                        </div>
                    </div>
                    <hr>
                    <div>
                        <canvas id="chart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row mt-2">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h4 class="mt-0 header-title">Tabel Hasil Pengujian | <?php echo e($testing->nama_testing); ?></h4>
                        </div>
                        <div class="col-md-6">
                            <a href="<?php echo e(route('uji.proses.export', ['testing_id' => $testing->id])); ?>" type="button"
                                class="btn btn-success" style="float: right">
                                <i class="fas fa-file-excel"></i>
                                Export Excel
                            </a>
                        </div>
                    </div>
                    <hr>
                    <table class="table table-bordered">
                        <thead>
                            <th width="10%">NO</th>
                            <th>USERNAME TWITTER</th>
                            <th>KALIMAT ASLI</th>
                            <th>KALIMAT PRE-PROCESSING</th>
                            <th>KATEGORI</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($row->username_twitter); ?></td>
                                    <td><?php echo e($row->post); ?></td>
                                    <td><?php echo e($row->kalimat); ?></td>
                                    <td>
                                        <?php if($row->kategori == 'Positif'): ?>
                                            <div class="badge badge-success">
                                                <?php echo e($row->kategori); ?>

                                            </div>
                                        <?php elseif($row->kategori == 'Negatif'): ?>
                                            <div class="badge badge-danger">
                                                <?php echo e($row->kategori); ?>

                                            </div>
                                        <?php else: ?>
                                            <div class="badge badge-info">
                                                <?php echo e($row->kategori); ?>

                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row mt-2">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h4 class="mt-0 header-title">Confusion Matrix | <?php echo e($testing->nama_testing); ?></h4>
                        </div>
                    </div>
                    <hr>
                    <table class="table table-bordered">
                        <thead>
                            <th>LABEL</th>
                            <th>PRECISION</th>
                            <th>RECALL</th>
                            <th>F1-SCORE</th>
                            <th>SUPPORT</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key); ?></td>
                                    <td><?php echo e($row['precision']); ?></td>
                                    <td><?php echo e($row['recall']); ?></td>
                                    <td><?php echo e($row['f1score']); ?></td>
                                    <td><?php echo e($row['support'] ?? '-'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-js'); ?>
    <script>
        var pieChart = {
            labels: [
                "Positif",
                "Negatif",
                "Netral"
            ],
            datasets: [{
                data: [<?php echo e($positif); ?>, <?php echo e($negatif); ?>, <?php echo e($netral); ?>],
                backgroundColor: [
                    "#02AC7B",
                    "#FC3B3B",
                    "#40BDFA"
                ],
                hoverBackgroundColor: [
                    "#02AC7B",
                    "#FC3B3B",
                    "#40BDFA"
                ],
                hoverBorderColor: "#fff"
            }]
        };
        var chart = new Chart($("#chart"), {
            type: "pie",
            data: pieChart
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Developer\laragon\www\s-janjijiwa\resources\views/pages/uji/proses/hasil.blade.php ENDPATH**/ ?>