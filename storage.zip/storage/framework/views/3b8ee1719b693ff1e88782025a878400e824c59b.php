<?php $__env->startSection('title', 'Pengelolaan Data Kata Yang Dihilangkan'); ?>
<?php $__env->startSection('breadcumb'); ?>
    <li class="breadcrumb-item"><a href="javascript:void(0);">Kelola Data</a></li>
    <li class="breadcrumb-item active">Kata Dihilangkan</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        
        <div class="col-md-6">
            <form action="<?php echo e(route('data.stopwords.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Tambah Data</h4>
                        <hr>
                        <div class="row">
                            <div class="col-md-7 mt-2">
                                <input name="kata" type="text" class="form-control"
                                    placeholder="Masukan Kata Yang Dihilangkan" required>
                            </div>
                            <div class="col-md-3 mt-2">
                                <button type="submit" class="btn btn-primary">
                                    Simpan
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="mt-0 header-title">Data Kata Yang Dihilangkan</h4>
                    <br>
                    <table class="table table-bordered">
                        <thead>
                            <th width="10%">NO</th>
                            <th>KATA</th>
                            <th>AKSI</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($row->kata); ?></td>
                                    <td>
                                        <button type="button" onclick="deleteData('<?php echo e(route('data.stopwords.delete', ['id' => $row->id])); ?>')"
                                            class="btn btn-danger btn-sm">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-js'); ?>
    <script>
        function deleteData(url) {
            Swal.fire({
                title: 'Menghapus Data',
                text: 'Data Kata Yang Dihilangkan akan Terhapus. Lanjutkan?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Hapus',
                cancelButtonText: 'Batalkan'
            }).then((res) => {
                if (res.isConfirmed) {
                    window.location.href = url;
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Developer\laragon\www\s-janjijiwa\resources\views/pages/stopwords/view.blade.php ENDPATH**/ ?>