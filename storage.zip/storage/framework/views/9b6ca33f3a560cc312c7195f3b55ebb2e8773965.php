<?php $__env->startSection('title', $test->nama_testing . ' | Ambil Data Dari Twitter'); ?>
<?php $__env->startSection('breadcumb'); ?>
    <li class="breadcrumb-item"><a href="javascript:void(0);">Pengujian</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('uji.testing')); ?>">Data Testing</a></li>
    <li class="breadcrumb-item active">Ambil Data Twitter</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-md-6">
            <form action="<?php echo e(route('uji.testing.detail.get')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label class="form-label">Kata Kunci</label>
                                <input type="hidden" name="test_id" value="<?php echo e($test->id); ?>">
                                <input type="text" name="keywords" id="keywords" class="form-control"
                                    placeholder="ex : Janji Jiwa" required>
                            </div>
                            <div class="form-group col-md-12 mt-2">
                                <label class="form-label">Jumlah Data</label>
                                <input type="number" value="10" name="qty" id="qty" min="10"
                                    max="100" class="form-control" placeholder="10-100" required>
                                <p style="margin: 0px;color:grey;font-size:11px">Masukan 10-100 Data</p>
                            </div>
                            <div class="form-group col-md-12 mt-2">
                                <button type="submit" class="btn btn-primary" style="float: right">Ambil Data</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-6">
            <p style="color: grey">
                Pada halaman ini akan mengambil data testing dari postingan netizen pada twitter. pastikan data testing
                kosong sebelum melakukan pengambilan data dari twitter.
            </p>
        </div>
    </div>

    
    <div class="row">
        <div class="col-md-12">
            <?php if(count($data) > 0): ?>
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Data Testing</h4>
                        <hr>
                        <table class="table table-bordered dt-responsive nowrap">
                            <thead>
                                <th width="10%">NO</th>
                                <th>POSTINGAN</th>
                                <th>USERNAME TWITTER</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($row->post); ?></td>
                                        <td><?php echo e($row->username_twitter); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else: ?>
            <div class="alert alert-warning">
                Belum ada data diambil
            </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Developer\laragon\www\s-janjijiwa\resources\views/pages/uji/testing/detil.blade.php ENDPATH**/ ?>