<?php $__env->startSection('title', 'Proses Klasifikasi'); ?>
<?php $__env->startSection('breadcumb'); ?>
    <li class="breadcrumb-item"><a href="javascript:void(0);">Pengujian</a></li>
    <li class="breadcrumb-item active">Proses Klasifikasi</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('uji.proses.view')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-3">
                        <label class="form-label">Pilih Testing</label>
                        <select name="testing" class="form-control">
                            <?php $__currentLoopData = $testing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tes->id); ?>"><?php echo e($tes->nama_testing); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3" style="margin-top:28px">
                        <button type="submit" class="btn btn-primary">Tampilkan Data</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <?php if($data != null): ?>
        <?php if(count($data) <= 0): ?>
            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="alert alert-warning">
                        Data Testing belum ada
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h4 class="mt-0 header-title">Data Pre-Processing</h4>
                                </div>
                                <div class="col-md-6">
                                    <button
                                        onclick="proses('<?php echo e(route('uji.proses.proses', ['testing_id' => $testing_id])); ?>')"
                                        type="button" class="btn btn-primary" style="float: right">
                                        <i class="fas fa-redo"></i>
                                        Proses Klasifikasi
                                    </button>
                                </div>
                            </div>
                            <hr>
                            <table class="table table-bordered">
                                <thead>
                                    <th width="10%">NO</th>
                                    <th>POSTINGAN</th>
                                    <th>USERNAME TWITTER</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($row->union); ?></td>
                                            <td><?php echo e($row->username); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-js'); ?>
    <script>
        function proses(url) {
            Swal.fire({
                title: 'Memproses Klasifikasi Naive Bayes',
                text: 'Anda akan melakukan proses klasifikasi Naive Bayes. Lanjutkan?',
                icon: 'info',
                showCancelButton: true,
                confirmButtonText: 'Proses',
                cancelButtonText: 'Batalkan'
            }).then((res) => {
                if (res.isConfirmed) {
                    window.location.href = url;
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Developer\laragon\www\s-janjijiwa\resources\views/pages/uji/proses/view.blade.php ENDPATH**/ ?>