

<?php $__env->startSection('title', 'Pre-Processing'); ?>
<?php $__env->startSection('breadcumb'); ?>
    <li class="breadcrumb-item"><a href="javascript:void(0);">Pengujian</a></li>
    <li class="breadcrumb-item active">Pre-Processing</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('uji.pre.view')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-3">
                        <label class="form-label">Pilih Testing</label>
                        <select name="testing" class="form-control">
                            <?php $__currentLoopData = $testing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tes->id); ?>"><?php echo e($tes->nama_testing); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3" style="margin-top:28px">
                        <button type="submit" class="btn btn-primary">Tampilkan Data</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    
    <?php if($data != null): ?>
        <?php if(count($data) <= 0): ?>
            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="alert alert-warning">
                        Data Testing belum ada
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h4 class="mt-0 header-title">Data Testing dari Twitter</h4>
                                </div>
                                <div class="col-md-6">
                                    <button onclick="proses('<?php echo e(route('uji.pre.proses', ['testing_id' => $testing_id])); ?>')"
                                        type="button" class="btn btn-primary" style="float: right">
                                        <i class="fas fa-redo"></i>
                                        Lakukan Pre-Processing
                                    </button>
                                </div>
                            </div>
                            <hr>
                            <table class="table table-bordered">
                                <thead>
                                    <th width="10%">NO</th>
                                    <th>POSTINGAN</th>
                                    <th>USERNAME TWITTER</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($row->post); ?></td>
                                            <td><?php echo e($row->username_twitter); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    

    
    <?php if(isset($pre)): ?>
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h4 class="mt-0 header-title">Data Pre-Processing</h4>
                            </div>
                        </div>
                        <hr>
                        <table class="tablepre table-bordered">
                            <thead>
                                <th>NO</th>
                                <th>USERNAME</th>
                                <th>CLEANSING</th>
                                <th>CASE FOLDING</th>
                                <th>TOKENIZING</th>
                                <th>STOPWORDS</th>
                                <th>STEMMING</th>
                                <th>CLEAN DATA</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pre['pre']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($row->username); ?></td>
                                        <td style="white-space:nowrap"><?php echo e($row->cleansing); ?></td>
                                        <td style="white-space:nowrap"><?php echo e($row->casefolding); ?></td>
                                        <td><?php echo e($row->tokenizing); ?></td>
                                        <td><?php echo e($row->stopwords); ?></td>
                                        <td><?php echo e($row->stemming); ?></td>
                                        <td style="white-space:nowrap"><?php echo e($row->union); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-js'); ?>
    <script>
        $(document).ready(function() {
            $('.tablepre').DataTable({
                "scrollX": true,
                "searching": false,
                "paging": false,
                "info": false
                // "scrollCollapse": true,
                // "columnDefs": [{
                //     "width": "20%",
                //     "targets": [1]
                // }, ],
            });
        });

        function proses(url) {
            Swal.fire({
                title: 'Lakukan Pre-Processing?',
                text: 'Anda akan melakukan Pre-processing. Lanjutkan?',
                icon: 'info',
                showCancelButton: true,
                confirmButtonText: 'Proses',
                cancelButtonText: 'Batalkan'
            }).then((res) => {
                if (res.isConfirmed) {
                    window.location.href = url;
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Developer\laragon\www\s-janjijiwa\resources\views/pages/uji/pre/view.blade.php ENDPATH**/ ?>