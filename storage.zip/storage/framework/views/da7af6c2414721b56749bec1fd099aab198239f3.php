<?php $__env->startSection('title', 'Pengelolaan Data Training'); ?>
<?php $__env->startSection('breadcumb'); ?>
    <li class="breadcrumb-item"><a href="javascript:void(0);">Kelola Data</a></li>
    <li class="breadcrumb-item active">Data Training</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="row">
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="mt-0 header-title">Tambah Data Satuan</h4>
                    <hr>
                    <form action="<?php echo e(route('data.training.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="form-label">Kalimat</label>
                                <textarea name="kalimat" placeholder="Masukan Kalimat" rows="2" class="form-control"></textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Kategori</label>
                                <select name="kategori" class="form-control">
                                    <option value="Positif">Positif</option>
                                    <option value="Negatif">Negatif</option>
                                    <option value="Netral">Netral</option>
                                </select>
                            </div>
                            <div class="col-md-12">
                                <button class="btn btn-primary btn-sm mt-2" style="float: right"
                                    type="submit">Tambah</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="mt-0 header-title">Import Excel</h4>
                    <hr>
                    <form action="<?php echo e(route('data.training.import')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-7">
                                <input type="file" name="file" accept=".csv,.xls,.xlsx" class="form-control" required>
                                <p style="margin: 0px;color:crimson;font-size:11px">*Format .csv,.xls,.xlsx (Max 2MB)</p>
                            </div>
                            <div class="col-md-5">
                                <button class="btn btn-success" type="submit">
                                    <i class="fa fa-file-excel"></i>
                                    Import
                                </button>
                            </div>
                            <div class="col-md-12 mt-3">
                                <a href="<?php echo e(asset('docs/template/template_data_training.xlsx')); ?>" class="btn btn-outline-success btn-sm">
                                    <i class="fa fa-file-excel"></i>
                                    Unduh Template
                                </a>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h4 class="mt-0 header-title">Data Training</h4>
                        </div>
                        <div class="col-md-6">
                            <button type="button" onclick="clearData('<?php echo e(route('data.training.clear')); ?>')" class="btn btn-outline-danger btn-sm" style="float: right">Bersihkan Data</button>
                        </div>
                    </div>
                    <br>
                    <table class="table table-bordered dt-responsive nowrap">
                        <thead>
                            <th width="10%">NO</th>
                            <th>KALIMAT</th>
                            <th>KATEGORI</th>
                            <th>AKSI</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($row->kalimat); ?></td>
                                    <td><?php echo e($row->kategori); ?></td>
                                    <td>
                                        <button type="button"
                                            onclick="deleteData('<?php echo e(route('data.training.delete', ['id' => $row->id])); ?>')"
                                            class="btn btn-danger btn-sm">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-js'); ?>
    <script>
        function deleteData(url) {
            Swal.fire({
                title: 'Menghapus Data',
                text: 'Data Training akan Terhapus. Lanjutkan?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Hapus',
                cancelButtonText: 'Batalkan'
            }).then((res) => {
                if (res.isConfirmed) {
                    window.location.href = url;
                }
            })
        }
        function clearData(url) {
            Swal.fire({
                title: 'Membersihkan Data',
                text: 'Membersihkan data akan menghapus semua data yang ada. Lanjutkan?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Bersihkan',
                cancelButtonText: 'Batalkan'
            }).then((res) => {
                if (res.isConfirmed) {
                    window.location.href = url;
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Developer\laragon\www\s-janjijiwa\resources\views/pages/training/view.blade.php ENDPATH**/ ?>