<?php $__env->startSection('title', 'Kelola Data Testing'); ?>
<?php $__env->startSection('breadcumb'); ?>
    <li class="breadcrumb-item"><a href="javascript:void(0);">Pengujian</a></li>
    <li class="breadcrumb-item active">Data Testing</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="row">
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="mt-0 header-title">Tambah Data</h4>
                    <hr>
                    <form id="form" action="<?php echo e(route('uji.testing.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <label class="form-label">Nama Testing</label>
                                <input type="hidden" name="id" id="id">
                                <input type="text" name="nama" id="nama" class="form-control"
                                    placeholder="Masukan Nama Testing" required>
                            </div>
                            <div class="col-md-12">
                                <button id="button" class="btn btn-primary btn-sm mt-2" style="float: right"
                                    type="submit">Tambah</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="mt-0 header-title">Data Training</h4>
                    <br>
                    <table class="table table-bordered dt-responsive nowrap">
                        <thead>
                            <th width="10%">NO</th>
                            <th>NAMA TESTING</th>
                            <th>TANGGAL</th>
                            <th>JUMLAH DATA</th>
                            <th>AKSI</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($row->nama_testing); ?></td>
                                    <td><?php echo e($row->tgl_testing); ?></td>
                                    <td>
                                        <?php if(count($row->data) > 0): ?>
                                            <div class="badge badge-primary"><?php echo e(count($row->data)); ?> Data</div>
                                        <?php else: ?>
                                            <div class="badge badge-danger">Belum ada data</div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button type="button"
                                            onclick="deleteData('<?php echo e(route('uji.testing.delete', ['id' => $row->id])); ?>')"
                                            class="btn btn-danger btn-sm">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                        <button type="button"
                                            onclick="editData('<?php echo e($row->id); ?>','<?php echo e($row->nama_testing); ?>','<?php echo e(route('uji.testing.update')); ?>')"
                                            class="btn btn-info btn-sm">
                                            <i class="fa fa-edit"></i>
                                        </button>
                                        <a href="<?php echo e(route('uji.testing.detail.view',['testing_id' => $row->id])); ?>" class="btn btn-sm btn-success">
                                            Detil
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-js'); ?>
    <script>
        function deleteData(url) {
            Swal.fire({
                title: 'Menghapus Data',
                text: 'Testing akan Terhapus. Lanjutkan?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Hapus',
                cancelButtonText: 'Batalkan'
            }).then((res) => {
                if (res.isConfirmed) {
                    window.location.href = url;
                }
            })
        }

        function editData(id, nama, action) {
            $('#id').val(id)
            $('#nama').val(nama)
            $('#button').html("Ubah Data")
            $('#form').attr('action', action)
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Developer\laragon\www\s-janjijiwa\resources\views/pages/uji/testing/view.blade.php ENDPATH**/ ?>