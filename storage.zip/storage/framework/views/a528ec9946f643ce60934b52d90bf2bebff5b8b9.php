<div class="left side-menu">
    <div class="slimscroll-menu" id="remove-scroll">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu" id="side-menu">
                <li class="menu-title">Menu</li>
                <?php $__currentLoopData = SideMenu::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($menu['tipe'] == '1'): ?>
                        <li>
                            <a href="<?php echo e(route($menu['route'])); ?>"
                                class="waves-effect <?php echo e(Request::segment(2) == $menu['index'] ? 'mm-active' : ''); ?> ">
                                <i class="<?php echo e($menu['icon']); ?>"></i>
                                <span><?php echo e($menu['menu']); ?></span>
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="<?php echo e(Request::segment(2) == $menu['index'] ? 'mm-active' : ''); ?> ">
                            <a href="javascript:void(0);" class="waves-effect">
                                <i class="<?php echo e($menu['icon']); ?>"></i>
                                <span><?php echo e($menu['menu']); ?>

                                    <span class="float-right menu-arrow">
                                        <i class="mdi mdi-chevron-right"></i>
                                    </span>
                                </span>
                            </a>
                            <ul class="submenu">
                                <?php if(count($menu['sub']) > 0): ?>
                                    <?php $__currentLoopData = $menu['sub']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route($sub['sub-route'])); ?>"><?php echo e($sub['sub-menu']); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <li>No Sub Menu</li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>
        <!-- Sidebar -->
        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->

</div>
<?php /**PATH C:\Developer\laragon\www\s-janjijiwa\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>