@extends('app')

@section('title', 'Halaman Utama')
@section('breadcumb')
    <li class="breadcrumb-item"><a href="javascript:void(0);">Stexo</a></li>
    <li class="breadcrumb-item active">Dashboard</li>
@endsection

@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-primary">
                Selamat Datang di Sistem Informasi Klasifikasi Menggunakan Metode Naive Bayes
            </div>
        </div>
    </div>
@endsection
